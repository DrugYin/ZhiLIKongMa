# 智慧控码后台管理网站

该目录是智慧控码训练系统的独立后台管理网站，当前已承载运营统计、系统配置、项目配置、用户管理、班级管理、任务管理、提交审核、排行榜、公告管理和操作日志等管理能力。

## 技术栈

- Vue 3
- Vite
- TDesign Vue Next
- Pinia
- Vue Router Hash 模式
- ECharts
- CloudBase Web SDK

## 本地启动

```bash
cd admin-web
npm install
npm run dev
```

首次启动前复制环境变量：

```bash
cp .env.example .env.local
```

Windows PowerShell 可手动复制 `.env.example` 为 `.env.local`。

基础登录需要在 `.env.local` 中补充 CloudBase Web Auth 访问密钥：

```text
VITE_CLOUDBASE_ENV_ID=zhi-li-kong-ma-7gy2aqcr1add21a7
VITE_CLOUDBASE_REGION=ap-shanghai
VITE_CLOUDBASE_ACCESS_KEY=你的 Web 访问密钥
```

同时需要在 CloudBase 身份认证中启用用户名/密码登录方式。

## 构建

```bash
npm run build
```

构建产物输出到：

```text
admin-web/dist/
```

## 云函数约定

后台前端不直接修改敏感集合，统一调用 `admin-*` 云函数：

- `admin-auth-check`
- `admin-get-statistics`
- `admin-manage-config`
- `admin-manage-projects`
- `admin-manage-users`
- `admin-manage-classes`
- `admin-manage-tasks`
- `admin-manage-submissions`
- `admin-manage-rankings`
- `admin-manage-announcements`
- `admin-manage-logs`

说明：排行榜快照刷新仍由小程序侧运维云函数 `refresh-ranking-snapshots` 承担，后台当前提供排行榜查看和历史快照查询入口。

## 管理员初始化

当前基础登录已接入 `admin-auth-check` 云函数。管理员仍然统一维护在 `users` 集合中，权限由 `roles` 字段控制：

```json
{
  "_openid": "小程序 openid",
  "phone": "13800000000",
  "user_name": "管理员",
  "roles": ["student", "teacher", "admin"],
  "admin_role": "super_admin",
  "admin_status": "active",
  "admin_auth_uid": "首次后台登录后自动写入",
  "admin_permissions": [
    "dashboard:read",
    "config:read",
    "config:write",
    "projects:read",
    "projects:write",
    "users:read",
    "tasks:read",
    "submissions:read",
    "logs:read"
  ]
}
```

首次登录后台时，`admin-auth-check` 会先用当前 CloudBase Web Auth 的 `uid` 查找 `users.admin_auth_uid`。如果还没有绑定，则使用当前 Web Auth 账号的手机号匹配 `users.phone`，匹配到且 `roles` 包含 `admin` 时自动写入 `admin_auth_uid`。后续登录将直接使用 `admin_auth_uid` 精确校验。

## 部署建议

部署到 CloudBase 静态网站托管的 `/admin/` 子目录，并使用 Hash 路由：

```text
/admin/#/dashboard
```

## 当前状态

当前已完成 Vue 3 后台工程、CloudBase Web Auth 登录、管理员权限校验、主布局和 11 个后台页面：

- 运营概览：`admin-get-statistics`
- 系统配置：`admin-manage-config`
- 项目配置：`admin-manage-projects`
- 用户管理：`admin-manage-users`
- 班级管理：`admin-manage-classes`
- 任务管理：`admin-manage-tasks`
- 提交记录与后台审核：`admin-manage-submissions`
- 排行榜：`admin-manage-rankings`
- 公告管理：`admin-manage-announcements`
- 操作日志：`admin-manage-logs`

下一步建议优先做后台真机/云环境联调、权限矩阵细化、CloudBase 静态网站托管部署，以及生产环境管理员账号初始化。
